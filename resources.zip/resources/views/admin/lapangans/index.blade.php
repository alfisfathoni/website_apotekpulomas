@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Daftar Obat</h3>
            <a href="{{route('lapangans.create')}}" class="btn btn-primary">Tambah Data</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Obat</th>
                            <th>Gambar Obat</th>
                            <th>Harga Obat</th>
                            <th>Stok Obat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($lapangans as $lapangan)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{$lapangan->nama_obat}}</td>
                                <td>
                                    <img src="{{Storage::url($lapangan->gambar)}}"  width="200" alt="">
                                </td>
                                <td>Rp. {{$lapangan->harga_obat}}</td>
                                <td>{{$lapangan->stock_obat}}</td>
                                <td>
                                    <a href="{{ route('lapangans.edit', $lapangan->id)}}" class="btn btn-sm btn-warning">Edit</a>
                                    <form onclick="return confirm('Anda Yakin Menghapus Data?');" class="d-inline" action="{{ route('lapangans.destroy', $lapangan->id)}}" method="post">
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center">Data Kosong</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
