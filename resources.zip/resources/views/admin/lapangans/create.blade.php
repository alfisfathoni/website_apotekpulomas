@extends('layouts.admin')

@section('content')
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    Form Edit Data
                </div>
                <div class="card-body">
                    <form action="{{ url('admin/lapangans')}}" method="post" enctype="multipart/form-data">
                        @csrf
                        {{-- @method('put') --}}
                        <div class="form-group">
                            <label for="nama_obat">Nama Obat</label>
                            <input type="text" name="nama_obat" class="form-control" value="{{ old('nama_obat')}}">
                        </div>
                        <div class="form-group">
                            <label for="harga_obat">IDR Harga Obat</label>
                            <input type="number" name="harga_obat" class="form-control" value="{{ old('harga_obat')}}">
                        </div>
                        <div class="form-group">
                            <label for="stocka_obat">Stock Obat</label>
                            <input type="number" name="stock_obat" class="form-control" value="{{ old('stock_obat')}}">
                        </div>
                        <div class="form-group">
                            <label for="no_registrasi">No Registrasi</label>
                            <input type="text" name="no_registrasi" class="form-control" value="{{ old('no_registrasi')}}">
                        </div>
                        <div class="form-group">
                            <label for="komposisi">Komposisi</label><br>
                            <input type="text" name="komposisi" class="form-control" value="{{ old('komposisi')}}">


                         <div class="form-group">
                            <label for="kategori">Kategori</label><br>
                            <input type="text" name="kategori" class="form-control" value="{{ old('kategori')}}">
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" id="deskripsi" cols="30" rows="5">{{old ('deskripsi')}}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="indikasi_umum">Indikasi Umum</label><br>
                            <input type="text" name="indikasi_umum" class="form-control" value="{{ old('indikasi_umum')}}">
                        </div>
                        <div class="form-group">
                            <label for="aturan_pakai">Aturan Pakai</label><br>
                            <input type="text" name="aturan_pakai" class="form-control" value="{{ old('aturan_pakai')}}">
                        </div>
                        <div class="form-group">
                            <label for="komposisi">Komposisi</label><br>
                            <input type="text" name="komposisi" class="form-control" value="{{ old('komposisi')}}">
                        </div>
                        <div class="form-group">
                            <label for="dosis">Dosis</label><br>
                            <input type="text" name="dosis" class="form-control" value="{{ old('dosis')}}">
                        </div>
                        <div class="form-group">
                            <label for="jenis_obat">Jenis Obat</label><br>
                            <input type="text" name="jenis_obat" class="form-control" value="{{ old('jenis_obat')}}">
                        <div class="form-group">
                            <label for="gambar">Gambar</label>
                            <input type="file" class="form-control" name="gambar">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
        {{-- <div class="card">
                <div class="card-header">
                    Form Edit Gambar
                </div>
                <div class="card-body">
                    <form action="{{ route('lapangans.create')}}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('put')
                        <div class="form-group">
                            <img src=""  class="img-fluid" alt="">
                        </div>
                        <div class="form-group">
                            <label for="gambar">Gambar</label>
                            <input type="file" class="form-control" name="gambar">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div> --}}
        </div>
    </div>
@endsection
