@extends('layouts.member')

@section('content')
    <div class="card">
        <div class="card-header">
            Form Edit Pesanan
        </div>
        <div class="card-body">
            <form action="{{'/pesan/'.$data->id}}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="form-group">
                    <label for="nama_lapangan">Nama </label>
                    <input type="text" name="nama" class="form-control" value="{{ $data->nama}}">
                </div>
                <div class="form-group">
                    <label for="harga_sewa">Nomor Hp</label>
                    <input type="number" name="no_hp" class="form-control" value="{{ $data->no_hp }}">
                </div>
                <div class="form-group">
                    <label for="nama_obat">obat</label><br>
                    <input type="radio" name="lapangan" class="form" value="Bonviva 150 mg" required="required"> Bonviva 150 mg <br>
                    <input type="radio" name="lapangan" class="form"value="Kolkatriol F 0.5 mcg" required="required"> Kolkatriol F 0.5 mcg <br>
                    <input type="radio" name="lapangan" class="form" value="Polysilane" required="required">Polysilane <br>
                    <input type="radio" name="lapangan" class="form"value="Zithromax 500 mg 3" required="required"> Zithromax 500 mg 3 <br>
                    <input type="radio" name="lapangan" class="form" value="Mucera Sirup 60 ml" required="required"> Mucera Sirup 60 ml <br>
                    <input type="radio" name="lapangan" class="form"value="Prome Sirup 100 ml" required="required"> Prome Sirup 100 ml <br>
                    <input type="radio" name="lapangan" class="form" value="Acetylcysteine 200 mg" required="required">Acetylcysteine 200 mg <br>
                    <input type="radio" name="lapangan" class="form"value="Telfast Plus" required="required"> Telfast Plus <br>
                    <input type="radio" name="lapangan" class="form"value="Actifed Plus Expectorant Sirup 60 ml 2 Botol" required="required"> Actifed Plus Expectorant Sirup 60 ml 2 Botol <br>
                    <input type="radio" name="lapangan" class="form"value="Actifed Plus Cough Supressant Sirup 60 ml (Merah)" required="required"> Actifed Plus Cough Supressant Sirup 60 ml (Merah) <br>
                </div>
                <div class="form-group">
                    <label for="nama_obat">Alamat </label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama')}}">
                </div>
                <div class="form-group">
                    <label for="gambar">Bukti Pembayaran</label>
                    <input type="file" class="form-control" name="foto">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
@endsection
