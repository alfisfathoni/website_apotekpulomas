@extends('layouts.frontend')

@section('content')
<header class="bg-dark py-5">
    <div class="container px-4 px-lg-5 my-5">
      <div class="text-center text-white">
        <h1 class="display-4 fw-bolder">Detail Obat</h1>
      </div>
    </div>
  </header>
  <!-- Section-->
  <section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
      <div class="row justify-content-center">
        <div class="col-lg-8 mb-5">
          <div class="card h-100">
            <!-- Product image-->
            <img
              class="card-img-top"
              src="{{Storage::url($lapangan->gambar)}}"
              alt="{{ $lapangan->nama_obat}}"
            />
            <!-- Product details-->
            <div class="card-body card-body-custom pt-4">
              <div>
                <!-- Product name-->
                <h3 class="fw-bolder text-primary">Detail Obat</h3>
                <p>
                  {{$lapangan->deskripsi}}
                </p>
                <div class="mobil-info-list border-top pt-4">
                    <h3>Detail Obat</h3>
                    <div class="row">
                        <div class="col-12">
                          <div class="row">
                            <div class="col-12">
                              <h3 class="fw-bold">Deskripsi</h3>
                              <span>{{$lapangan->deskripsi}}</span>
                            </div> 
                          </div>
                        </div>
                        <div class="col-12">
                          <div class="row">
                            <div class="col-12">
                              <h3 class="fw-bold">Indikasi Umum</h3>
                              <span>{{$lapangan->indikasi_umum}}</span>
                            </div> 
                          </div>
                        </div>
                        <div class="col-12">
                          <div class="row">
                            <div class="col-12">
                              <h3 class="fw-bold">Komposisi</h3>
                              <span>{{$lapangan->komposisi}}</span>
                            </div> 
                          </div>
                        </div>
                        <div class="col-12">
                          <div class="row">
                            <div class="col-12">
                              <h3 class="fw-bold">Dosis</h3>
                              <span>{{$lapangan->dosis}}</span>
                            </div> 
                          </div>
                        </div>
                        <div class="col-12">
                          <div class="row">
                            <div class="col-12">
                              <h3 class="fw-bold">Aturan Pakai</h3>
                              <span>{{$lapangan->aturan_pakai}}</span>
                            </div> 
                          </div>
                        </div>
                        <div class="col-12">
                          <div class="row">
                            <div class="col-12">
                              <h3 class="fw-bold">NO Registrasi</h3>
                              <span>{{$lapangan->no_registrasi}}</span>
                            </div> 
                          </div>
                        </div>
                    </div>

                  {{-- <ul class="list-unstyled">
                    <li>
                      @if($lapangan->kategori)
                        <span>Kategori</span>
                        <span>{{$lapangan->kategori}}</span>
                      @else
                        <i class="ri-close-circle-line text-secondary"></i>
                        <span>Kategori</span>
                      @endif
                    </li>
                    <li>
                      @if($lapangan->stock_obat)
                      <i class="ri-checkbox-circle-line"></i>
                      <span>Stok Obat</span>
                    @else
                    <i class="ri-close-circle-line text-secondary"></i>
                      <span>Stok Obat</span>
                    @endif
                    </li>
                    <li>
                      @if($lapangan->indikasi_umum)
                      <i class="ri-checkbox-circle-line"></i>
                      <span>Indikasi Umum</span>
                    @else
                    <i class="ri-close-circle-line text-secondary"></i>
                      <span>Indikasi Umum</span>
                    @endif
                    </li>
                    <li>
                      @if($lapangan->komposisi)
                      <i class="ri-checkbox-circle-line"></i>
                      <span>Aturan Pakai</span>
                    @else
                    <i class="ri-close-circle-line text-secondary"></i>
                      <span>Aturan Pakai</span>
                    @endif
                    </li>
                  </ul> --}}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-5">
          <div class="card">
            <!-- Product details-->
            <div class="card-body card-body-custom pt-4">
              <div class="text-center">
                <!-- Product name-->
                <div
                  class="d-flex justify-content-between align-items-center"
                >
                  <h5 class="fw-bolder">{{$lapangan->nama_obat}}</h5>
                  <div class="rent-price mb-3">
                    <span style="font-size: 1rem" class="text-primary"
                      >Rp.{{number_format ($lapangan->harga_obat)}}/</span
                    >
                  </div>
                </div>
                <ul class="list-unstyled list-style-group">
                  <li
                    class="border-bottom p-2 d-flex justify-content-between"
                  >
                    <span>Jenis Obat</span>
                    <span style="font-weight: 600">{{$lapangan->jenis_obat}}</span>
                  </li>
                  <li
                    class="border-bottom p-2 d-flex justify-content-between"
                  >
                    <span>stok</span>
                    <span style="font-weight: 600">{{$lapangan->stock_obat}}</span>
                  </li>
                </ul>
              </div>
            </div>
            <!-- Product actions-->
            <div class="card-footer border-top-0 bg-transparent">
              <div class="text-center">
                <a
                  class="btn d-flex align-items-center justify-content-center btn-primary mt-auto"
                  href="{{ auth()->check() ? url('/pesan') : url('/sesi') }}"
                  style="column-gap: 0.4rem"
                  >Beli Obat
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
@endsection
