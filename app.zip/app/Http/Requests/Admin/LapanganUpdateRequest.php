<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class LapanganUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'nama_obat' => 'required',
            'harga_obat'=> 'required',
            // 'gambar' => 'required|image',
            'no_registrasi' => 'required',
            'stock_obat' => 'required',
            'jenis_obat' => 'required',
            'kategori' => 'required',
            'deskripsi' => 'required',
            'indikasi_umum' => 'required',
            'aturan_pakai' => 'required',
            'komposisi' => 'required',
            'dosis' => 'required',
        ];
    }
}
