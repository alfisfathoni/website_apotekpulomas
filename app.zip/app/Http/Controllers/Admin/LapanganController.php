<?php

namespace App\Http\Controllers\Admin;

use App\Models\Lapangan;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\LapanganStoreRequest;
use App\Http\Requests\Admin\LapanganUpdateRequest;

class LapanganController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $lapangans = Lapangan::latest()->get();

        return view('admin.lapangans.index', compact('lapangans'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.lapangans.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(LapanganStoreRequest $request)
    {
        // dd();
        if($request->validated()){
            $gambar = $request->file('gambar')->store('assets/lapangan', 'public');
            $slug = Str::slug('$request->nama_obat', '-');
            Lapangan::create($request->except('gambar') + ['gambar' => $gambar, 'slug' => $slug]);
        }

        return redirect()->route('lapangans.index')->with([
            'message' => 'Data Berhasil Dibuat',
            'alert-type' => 'success'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Lapangan $lapangan)
    {
        return view('admin.lapangans.edit', compact('lapangan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(LapanganUpdateRequest $request,Lapangan $lapangan)
    {
        if($request->validated()){
            $slug = Str::slug($request->nama_obat, '-');
            $lapangan->update($request->validated() + ['slug' => $slug]);
        }

        return redirect()->route('lapangans.index')->with([
            'message'=>'Data Berhasil Di Edit',
            'alert-type'=>'info'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Lapangan $lapangan)
    {
        if($lapangan->gambar){
            unlink('storage/'. $lapangan->gambar);
        }
        $lapangan->delete();

        return redirect()->back()->with([
            'message'=>'Data Berhasil Di Hapus',
            'alert-type' => 'danger'
        ]);
    }

    public function updateImage(Request $request, $lapanganId)
    {
        $request->validate([
            'gambar' => 'required|image'
        ]);
        $lapangan = Lapangan::findOrFail($lapanganId);
        if($request->gambar){
            unlink('storage/'. $lapangan->gambar);
            $gambar = $request->file('gambar')->store('assets/lapangan', 'public');

            $lapangan->update(['gambar' => $gambar]);
        }

        return redirect()->back()->with([
            'message' => 'Gambar Berhasil Di Edit',
            'alert-type' => 'info'
        ]);
    }
}
