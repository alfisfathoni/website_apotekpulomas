<?php

namespace App\Http\Controllers;

use App\Models\MemberModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DaftarPesanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = MemberModel::all();
        $no = 1;
        return view('admin.daftarpesan.index')->with([
            'data'=>$data,
            'no'=>$no,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.daftarpesan.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // $request->validate([
        //     'nama'=>'required',
        //     'no_hp'=>'required',
        //     'lapangan'=>'required',
        //     'gambar'=>'required',
        // ]);

        $foto_file = $request->file('foto');
        $foto_extensi = $foto_file->extension();
        $foto_nama = date('ymdhis').".".$foto_extensi;
        $foto_file->move(public_path('foto'), $foto_nama);

        $data = [
            'nama'=>$request->input('nama'),
            'no_hp'=>$request->input('no_hp'),
            'lapangan'=>$request->input('obat'),
            'bukti_pembayaran'=>$foto_nama,
        ];

        MemberModel::create($data);
        return redirect('/daftarpesan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
