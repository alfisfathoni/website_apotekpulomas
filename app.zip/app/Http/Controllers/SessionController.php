<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class SessionController extends Controller
{
    //
    public function index(){
        return view('sesi.index ');
    }
    public function login(Request $request){
        $request->validate([
            'email'=>'required',
            'password'=>'required',
        ]);

        $info_login = [
            'email'=>$request->email,
            'password'=>$request->password,
        ];

        if(Auth::attempt($info_login)){

            if(Auth::User()->usertype === 0){
                return redirect('/member/dashboard');

            }elseif(Auth::User()->usertype === 1){
                return redirect('/admin/dashboard');

            }
        }else{
            return redirect('/sesi');
        }

    }

    public function register(){
        return view('sesi.register');
    }
    public function create(Request $request){
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'password'=>'required',
        ]);

        $data = [
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
        ];

        User::create($data);
        return redirect('/sesi')->with('success','Berhasil Menambahkan Data');
    }

    public function logout(){
        Auth::logout();
        return redirect('/sesi');
    }
}
