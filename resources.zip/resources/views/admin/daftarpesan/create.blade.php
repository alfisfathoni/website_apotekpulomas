@extends('layouts.member')

@section('content')
    <div class="card">
        <div class="card-header">
            Form Tambah Pesanan
        </div>
        <div class="card-body">
            <form action="/pesan" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="nama_obat">Nama </label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama')}}">
                </div>
                <div class="form-group">
                    <label for="harga_obat">Nomor Hp</label>
                    <input type="number" name="no_hp" class="form-control" value="{{ old('nomor_hp')}}">
                </div>
                <div class="form-group">
                    <label for="nama_obat">obat</label><br>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama_obat')}}">
                </div>
                <div class="form-group">
                    <label for="nama_obat">Alamat </label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama')}}">
                </div>
                <div class="form-group">
                    <label for="gambar">Gambar</label>
                    <input type="file" class="form-control" name="foto">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
@endsection
