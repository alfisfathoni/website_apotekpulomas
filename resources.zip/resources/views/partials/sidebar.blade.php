<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ route('admin.dashboard.index')}}">
        <div class="sidebar-brand-icon rotate-n-15">
            {{--  <i class="fas fa-laugh-wink"></i>  --}}
        </div>
        <div class="sidebar-brand-text mx-3">Apotek Pulomas</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="{{ route('admin.dashboard.index')}}">
            {{--  <i class="fas fa-fw fa-tachometer-alt"></i>  --}}
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <li class="nav-item active">
        <a class="nav-link" href="{{ route('lapangans.index')}}">
            {{--  <i class="fas fa-fw fa-tachometer-alt"></i>  --}}
            <span>Daftar Obat</span></a>
    </li>

    <li class="nav-item active">
        <a class="nav-link" href="{{ route('admin.messages.index')}}">
            {{--  <i class="fas fa-fw fa-tachometer-alt"></i>  --}}
            <span>Daftar Contact</span></a>
    </li>

    <li class="nav-item active">
        <a class="nav-link" href="/daftarpesan">
            {{--  <i class="fas fa-fw fa-tachometer-alt"></i>  --}}
            <span>Daftar Pesan</span></a>
    <li class="nav-item active">
        <a class="nav-link" href="/daftarpesan">
            {{--  <i class="fas fa-fw fa-tachometer-alt"></i>  --}}
            <span>Laporan keuangan</span></a>
    <li class="nav-item active">
        <a class="nav-link" href="/daftarpesan">
                    {{--  <i class="fas fa-fw fa-tachometer-alt"></i>  --}}
            <span>Kurir</span></a>

        @if (Auth::User()->usertype === 1)
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Custom Components:</h6>
                <a class="collapse-item" href="buttons.html">Buttons</a>
                <a class="collapse-item" href="cards.html">Cards</a>
            </div>
        </div>
        @elseif (Auth::User()->usertype === 0)
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Beli Obat:</h6>
                <a class="collapse-item" href="/pesan">Pesan</a>
            </div>
        </div>
        @endif


        <li class="nav-item active">
            <a class="nav-link" href="/logout">

                <span>Logout</span></a>
    </li>

</ul>
