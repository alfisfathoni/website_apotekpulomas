<?php

namespace App\Http\Controllers;

use App\Models\Lapangan;
use Illuminate\Http\Request;
use App\Models\Message;

class HomeController extends Controller
{
    public function index()
    {
        $lapangans = Lapangan::latest()->get();

        return view('frontend.homepage', compact('lapangans'));
    }

    public function contact()
    {
        return view('frontend.contact');
    }

    public function contactStore(Request $request)
    {
        $data = $request->validate([
            'nama' => 'required',
            'email' => 'required',
            'subject' => 'required',
            'pesan' => 'required',
            'g-recaptcha-response' => 'recaptcha',
        ]);

        Message::create($data);

        return redirect()->back()->with([
            'message' => 'Pesan Anda Berhasil Dikirim',
            'alert-type' => 'success'
        ]);
    }

    public function detail(Lapangan $lapangan)
    {
        return view('frontend.detail', compact('lapangan'));
    }
}
