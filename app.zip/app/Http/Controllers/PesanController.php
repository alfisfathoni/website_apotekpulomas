<?php

namespace App\Http\Controllers;

use App\Models\MemberModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PesanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = MemberModel::all();
        $no = 1;
        return view('pesan.index')->with([
            'data'=>$data,
            'no'=>$no,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pesan.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // $request->validate([
        //     'nama'=>'required',
        //     'no_hp'=>'required',
        //     'lapangan'=>'required',
        //     'gambar'=>'required',
        // ]);

        $foto_file = $request->file('foto');
        $foto_extensi = $foto_file->extension();
        $foto_nama = date('ymdhis').".".$foto_extensi;
        $foto_file->move(public_path('foto'), $foto_nama);

        $data = [
            'nama'=>$request->input('nama'),
            'no_hp'=>$request->input('no_hp'),
            'lapangan'=>$request->input('obat'),
            'alamat'=>$request->input('alamat'),
            'bukti_pembayaran'=>$foto_nama,
        ];

        MemberModel::create($data);
        return redirect('/pesan')->with([
            'message' => 'Data Berhasil Di Buat',
            'alert-type' => 'success'
        ]);;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $data = MemberModel::where('id',$id)->first();
        return view('pesan.edit')->with('data',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $foto_file = $request->file('foto');
        $foto_extensi = $foto_file->extension();
        $foto_nama = date('ymdhis').".".$foto_extensi;
        $foto_file->move(public_path('foto'), $foto_nama);

        $data = [
            'nama'=>$request->input('nama'),
            'no_hp'=>$request->input('no_hp'),
            'lapangan'=>$request->input('lapangan'),
            'alamat'=>$request->input('alamat'),
            'bukti_pembayaran'=>$foto_nama,
        ];

        MemberModel::where('id',$id)->update($data);
        return redirect('/pesan')->with([
            'message' => 'Data Berhasil Di Edit',
            'alert-type' => 'success'
        ]);;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        MemberModel::where('id',$id)->delete();
        return redirect('/pesan')->with([
            'message' => 'Data Berhasil Di Hapus',
            'alert-type' => 'success'
        ]);
    }
}
