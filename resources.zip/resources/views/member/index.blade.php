@extends('layouts.member')

@section('content')
<div class="row">

    <!-- Earnings (Monthly) Card Example -->
    <div class="container mb-5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card border-0 shadow rounded">
                            <div class="card-body">
                                <h3>Member</h3>
                                <h3>Selamat Datang  <span>{{Auth::User()->name}}</span>,</h3>
                                <img src="{{ asset('asset/images/poster.png')}}" alt="" width="100%">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
@endsection
