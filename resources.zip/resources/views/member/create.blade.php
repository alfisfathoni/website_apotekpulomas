@extends('layouts.member')

@section('content')
    <div class="card">
        <div class="card-header">
            Form Tambah Pesanan
        </div>
        <div class="card-body">
            <form action="{{ route('lapangans.store')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="nama_lapangan">Nama </label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama')}}">
                </div>
                <div class="form-group">
                    <label for="harga_sewa">Nomor Hp</label>
                    <input type="number" name="nomor_hp" class="form-control" value="{{ old('nomor_hp')}}">
                </div>
                <div class="form-group">
                    <label for="nama_obat">obat</label><br>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama_obat')}}">
                </div>
                <div class="form-group">
                    <label for="nama_obat">Alamat </label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama')}}">
                </div>
                <div class="form-group">
                    <label for="gambar">Gambar</label>
                    <input type="file" class="form-control" name="gambar">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
@endsection
