<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lapangans', function (Blueprint $table) {
            $table->id();
            $table->string('nama_obat');
            $table->string('slug');
            $table->integer('harga_obat');
            $table->text('gambar');
            $table->string('no_registrasi');
            $table->string('stock_obat');
            $table->string('kategori');
            $table->string('deskripsi');
            $table->text('indikasi_umum');
            $table->boolean('aturan_pakai');
            $table->boolean('komposisi');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lapangans');
    }
};
