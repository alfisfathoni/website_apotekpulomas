@extends('layouts.member')

@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Daftar Pesan Obat</h3>
            <a href="/pesan/create" class="btn btn-primary">Tambah Pesan</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                                @if(session()->has('message'))
                    <div class="alert alert-{{ session()->get('alert-type') }}  alert-dismissible fade show" role="alert">
                        {{session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    @endif
                    @if ($errors->any())
                        <div class="alert alert-danger">
                             <ul>
                                 @foreach ($errors->all() as $error)
                                   <li>{{ $error }}</li>
                                 @endforeach
                              </ul>
                        </div>
                    @endif
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nomor Hp</th>
                            <th>Obat</th>
                            <th>Alamat</th>
                            <th>Bukti Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($data as $item)
                            <tr>
                                <td>{{$no++}}</td>
                                <td>{{$item->nama}}</td>
                                <td>{{$item->no_hp}}</td>
                                <td>
                                    @if ($item->bukti_pembayaran)

                                    <img src="{{ url('foto').'/'.$item->bukti_pembayaran }}" width="200" alt="">
                                    @endif
                                </td>
                                <td>{{$item->lapangan}}</td>
                                <td>Pending</td>
                                <td>
                                    <a href="{{url('/pesan/'.$item->id.'/edit')}}" class="btn btn-sm btn-warning">Edit</a>
                                    <form onclick="return confirm('Anda Yakin Menghapus Data?');" class="d-inline" action="{{'/pesan/'.$item->id}}" method="post">
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                                {{--  <td><a href="{{ route('pesan.edit', $item->id)}}" class="btn btn-sm btn-warning">Edit</a></td>  --}}
                            </tr>
                            @empty
                            <tr>
                                 <td colspan="6" class="text-center">Data Kosong</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
